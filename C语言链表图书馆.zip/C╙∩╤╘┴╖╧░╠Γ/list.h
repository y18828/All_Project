#ifndef _LIST_H
#define _LIST_H

#include"data.h"    
#include"student.h"


typedef struct _s_list{
	int list_size;  
	s_node* head;   
}s_list;

s_list* New_list();
void free_list(s_list* one);
//s_list* link;  //定义一个链表  全局变量引用 
int add_data_field_from_head(s_list* list,student* data_field,long data_length);
int add_data_field_from_end(s_list* list,student* data_field,long data_length);
int add_data_field_by_index(s_list* list,int index,student* data_field,long data_length);

void* remove_data_field_from_head(s_list* list);
void* remove_data_field_from_end(s_list* list);
void* remove_data_field_by_index(s_list* list,int index);

void* get_data_field_by_index(s_list* list,int index); 

#endif
