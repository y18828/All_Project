#include<stdio.h>
#include<string.h>
#include<stddef.h>
#include<stdlib.h>
#include"data.h"
#include"list.h"
#include"student.h"

//������Ϊ��ʵ�� 
s_list* New_list()
{
	//�����ṹ�� 
	s_list* temp=(s_list*)malloc(sizeof(s_list));
	if(temp!=NULL)
	{
		memset(temp,0,sizeof(s_list));
	}
	return temp;
}

//��ͷ������ 
int add_data_field_from_head(s_list* list,student* data_field,long data_length)
{
	s_node* one=New_node();
	if(one==NULL)
	{
		return 0;
	}
	one->data_field=data_field;
	one->data_length=data_length; 
	if(list==NULL||data_field==NULL||data_length==0)
	{
		return 0;
    }
    one->data_field=data_field;
	one->data_length=data_length; 
	if(list->list_size==0)  
	{
		list->head=one;
		list->list_size+=1;
	} 
	else
	{
		one->next=list->head;
		list->head=one;
		list->list_size+=1;
	}
    return 1;
}
int add_data_field_from_end(s_list* list,student* data_field,long data_length)
{
	s_node* one=New_node();
	s_node* find=NULL;
	if(one==NULL)
	{
		return 0;
	} 
	if(list==NULL||data_field==NULL||data_length==0)
	{
		return 0;
	}
	one->data_field=data_field;
	one->data_length=data_length; 
	if(list->list_size==0)
		{
			list->head=one;
			list->list_size+=1; 
		}
	else
		{
			find=list->head;
			while(find->next!=NULL)
			{
				find=find->next;
			}
			find->next=one;
			list->list_size+=1;	
		}
	return 1;
}
int add_data_field_by_index(s_list* list,int index,student* data_field,long data_length)
{
	s_node* one=NULL;
	s_node* find=NULL;
	int i=0;
	if(list==NULL||data_field==NULL||data_length==0)
	{
		return 0;
	} 
	if(index<0||index>list->list_size)
	{
		return 0;
	}
	else
	{
		one=New_node(); 
		if(one==NULL)
		{
			return 0;
		}
		one->data_field=data_field;
	    one->data_length=data_length; 
		if(list->list_size==0)
		{
			list->head=one;
			list->list_size+=1; 
		}
		else  //�ڵ���������1��ʱ 
		{
			if(index==0)
			{
				one->next=list->head;
				list->head=one;
				list->list_size+=1;
			}
			else if(index==list->list_size)
			{
				find=list->head;
				while(find->next!=NULL)
				{
					find=find->next;
				}
				find->next=one;
				list->list_size+=1; 
			}
			else
			{
				find=list->head;
				while((i+1)!=index)
				{
					find=find->next;
					i++;
				}
				one->next=find->next;
				find->next=one;
				list->list_size+=1;
			}
		}
	}
}
void* remove_data_field_from_head(s_list* list)
{
	s_node* temp=NULL;
	void* rt=NULL;
	if(list==NULL||list->list_size==0)
	{
		return NULL;
	}
	else if(list->list_size==1)
		{
			temp=list->head;
			list->head==NULL;
			list->list_size-=1;
			rt=temp->data_field;
			free_node(temp);
		}
		else
		{
			temp=list->head;
			list->head=list->head->next;
			list->list_size-=1;
			rt=temp->data_field;
			free_node(temp); 
		}
	return rt;
}
void* remove_data_field_from_end(s_list* list)
{
	s_node* find_tail=NULL;
	void* rt=NULL;
	if(list==NULL||list->list_size==0)
	{
		return NULL;
	} 
	else if(list->list_size==1)
		{
			find_tail=list->head;
			list->head=NULL;
			list->list_size-=1;
			rt=find_tail->data_field;
			free_node(find_tail);
		}
		else
		{
			find_tail=list->head;
			while(find_tail->next->next!=NULL)
			{
				find_tail=find_tail->next;
			}
			rt=find_tail->next->data_field;
			free_node(find_tail->next); 
			find_tail->next=NULL;
			list->list_size-=1; 
		}
		 return rt;
} 
void* remove_data_field_by_index(s_list* list,int index)
{
	s_node* temp=NULL;
	s_node* find=NULL;
	int i = 0;
	void* rt=NULL;
	if(list==NULL||list->list_size==0)
	{
		return NULL;
	}
	if(index<0||index>=list->list_size)
	{
		return NULL;
	}
	else  
	{
		if(index==0)
		{
			temp=list->head;
			list->head=list->head->next;
			list->list_size-=1;
			rt=temp->data_field;
			free_node(temp);
		 } 
		 else if(index==list->list_size-1)
		 {
		 	find=list->head;
		 	while(find->next->next!=NULL)
		 	{
		 		find=find->next;
			}
			rt=find->next->data_field;
			temp=find->next;
			free_node(temp);
			find->next=NULL;
			list->list_size-=1;
		 }
		 else
		 {
		 	find=list->head;
		 	while((i+1)!=index)
		 	{
		 		find=find->next;
		 		i++;
			}
			temp=find->next;
			find->next=find->next->next;
			rt=temp->data_field;
			free_node(temp);
			list->list_size-=1;	 
		 } 
	}
	return rt;
}

