#ifndef _STUDENT_H
#define _STUDENT_H

#define MAX_NAME 20;
#define MAX_NO 20;
#define MAX_SCHOOL 20;
typedef struct _student{
	char* name;
	char* no;
	char* school;
	int age;
}student;

student* New_student();
void free_student(student* temp);
#endif
