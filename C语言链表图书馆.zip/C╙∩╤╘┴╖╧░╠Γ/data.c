#include<stdio.h>
#include<string.h>
#include<stddef.h>
#include<stdlib.h>
#include"data.h"
#include"student.h"
s_node* New_node()
{
	s_node* temp=(s_node*)malloc(sizeof(s_node));
	if(temp!=NULL)
	{
		memset(temp,0,sizeof(s_node));
	}
	return temp;
}
void free_node(s_node* one)
{
	if(one!=NULL)
	{
		free(one);
	}
}
