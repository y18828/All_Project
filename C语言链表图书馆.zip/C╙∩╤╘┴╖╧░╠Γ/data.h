#ifndef _DATA_H
#define _DATA_H
#include"student.h"  
typedef struct _s_node{
	student* data_field; 
	long data_length;     
	struct _s_node *next;  
}s_node;
s_node* head;
s_node* New_node();
void free_node(s_node* one);
#endif	
