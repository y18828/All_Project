DROP TABLE IF EXISTS `tables`;
CREATE TABLE `tables`(
`tables_id` int(6) AUTO_INCREMENT,
`tables_time` varchar(13) NOT NULL,
PRIMARY KEY (`tables_id`)
)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `stu`;
CREATE TABLE `stu` (
`stu_id` int(6) AUTO_INCREMENT,
`stu_name` varchar(64) NOT NULL,
`stu_sex` varchar(8) NOT NULL,
`stu_age` int(3) NOT NULL,
PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `par`;
CREATE TABLE `par`(
`par_id` int(6) AUTO_INCREMENT,
`par_name` varchar(15) NOT NULL,
`par_phone` varchar(13) NOT NULL,
PRIMARY KEY (`par_id`)
)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pay`;
CREATE TABLE `pay`(
`pay_id` int(6) AUTO_INCREMENT,
`pay_price` int(6) NOT NULL,
`pay_time` varchar(13) NOT NULL,
PRIMARY KEY (`pay_id`)
)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
