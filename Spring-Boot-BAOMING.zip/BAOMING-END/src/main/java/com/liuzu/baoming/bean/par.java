package com.liuzu.baoming.bean;

public class par {

	private int par_id;      	 //家长ID
	private String par_name; 	 //家长姓名
	private String par_phone;  	 //家长联系方式

	
	public int getPar_id() {
		return par_id;
	}
	public void setPar_id(int par_id) {
		this.par_id = par_id;
	}
	public String getPar_name() {
		return par_name;
	}
	public void setPar_name(String par_name) {
		this.par_name = par_name;
	}
	public String getPar_phone() {
		return par_phone;
	}
	public void setPar_phone(String par_phone) {
		this.par_phone = par_phone;
	}

	
	
	
	
}
