package com.liuzu.baoming.bean;
/**
 * 
 * @Author Wyc
 * @Time: 2018骞�11鏈�17鏃� 涓嬪崍11:32:40
 * @Description: TODO
 */
public class tables {

		private int tables_id;  		
		private String tables_time;		
		
		
		private par parents;				
		private pay pay;					
		private stu student; 				
		public int getTables_id() {
			return tables_id;
		}
		public void setTables_id(int tables_id) {
			this.tables_id = tables_id;
		}
		public String getTables_time() {
			return tables_time;
		}
		public void setTables_time(String tables_time) {
			this.tables_time = tables_time;
		}
		public par getPr() {
			return parents;
		}
		public void setPr(par par) {
			this.parents = par;
		}
		public pay getPy() {
			return pay;
		}
		public void setPy(pay py) {
			this.pay = py;
		}
		public stu getSu() {
			return student;
		}
		public void setSu(stu su) {
			this.student = su;
		}
}
