package com.liuzu.baoming.bean;

public class pay {

	private int pay_id;   		    //缴费ID
	private int pay_price;  		//金额
	private String pay_time; 		//时间
	
	
	public int getPay_id() {
		return pay_id;
	}
	public void setPay_id(int pay_id) {
		this.pay_id = pay_id;
	}
	public int getPay_price() {
		return pay_price;
	}
	public void setPay_price(int pay_price) {
		this.pay_price = pay_price;
	}
	public String getPay_time() {
		return pay_time;
	}
	public void setPay_time(String pay_time) {
		this.pay_time = pay_time;
	}

	
}
