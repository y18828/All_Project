package com.liuzu.baoming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaomingEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaomingEndApplication.class, args);
	}
}
