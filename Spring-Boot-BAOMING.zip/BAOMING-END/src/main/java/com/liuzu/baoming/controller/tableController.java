package com.liuzu.baoming.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.liuzu.baoming.bean.tables;

@RestController
public class tableController {
	
	
	@Autowired
	JdbcTemplate jdbc;
	
	@GetMapping("/tables")
	public Object getTab()
	{   String sqls="select * from tables";
	  List<Map<String, Object>> listss = jdbc.queryForList(sqls); 
	  List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();
		
	  for(Map<String,Object> map6:listss)
	  {Map<String,Object> maps=new LinkedHashMap<String,Object>();
		  Object a=map6.get("tables_id");
		  int id=Integer.parseInt(String.valueOf(a));
		  String sql = "select * from tables "
					+ "where tables_id = " + id;
			 List<Map<String, Object>> list1 = jdbc.queryForList(sql); 
			 for(Map<String, Object> map1:list1)
			 {
				 for(String key:map1.keySet())
				 {
				 maps.put(key, map1.get(key));
				 }
			 }
			 String sql1 = "select * from pay "
						+ "where pay_id = " + id;
			 List<Map<String, Object>> list2 = jdbc.queryForList(sql1); 
			 for(Map<String, Object> map2:list2)
			 {
				 maps.put("pay", map2);
			 }
			 String sql2 = "select * from par "
						+ "where par_id = " + id;
			 List<Map<String, Object>> list3 = jdbc.queryForList(sql2);
			 for(Map<String, Object> map3:list3)
			 {
				 maps.put("parents", map3);
			 }
			 String sql3 = "select * from stu "
						+ "where stu_id = " + id;
			 List<Map<String, Object>> list4 = jdbc.queryForList(sql3);
			 
			 for(Map<String, Object> map4:list4)
			 {
				 maps.put("student", map4);
			 }
			 lists.add(maps);
	  }
		
	              
		return lists;
	}
	
	@GetMapping("/tables/{id}")
	public Object getTabById(@PathVariable("id") String id) 
	{
		List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();
		Map<String,Object> maps=new LinkedHashMap<String,Object>();
		String sql = "select * from tables "
		+ "where tables_id = " + id;
		 List<Map<String, Object>> list1 = jdbc.queryForList(sql); 
		 for(Map<String, Object> map1:list1)
		 {
		 for(String key:map1.keySet())
		 {
		 maps.put(key, map1.get(key));
		 }
		 }
		 String sql1 = "select * from pay "
					+ "where pay_id = " + id;
		 List<Map<String, Object>> list2 = jdbc.queryForList(sql1); 
		 for(Map<String, Object> map2:list2)
		 {
			 maps.put("pay", map2);
		 }
		 String sql2 = "select * from par "
					+ "where par_id = " + id;
		 List<Map<String, Object>> list3 = jdbc.queryForList(sql2);
		 for(Map<String, Object> map3:list3)
		 {
			 maps.put("parents", map3);
		 }
		 String sql3 = "select * from stu "
					+ "where stu_id = " + id;
		 List<Map<String, Object>> list4 = jdbc.queryForList(sql3);
		 
		 for(Map<String, Object> map4:list4)
		 {
			 maps.put("student", map4);
		 }
		 lists.add(maps);
		return lists.get(0);
	}
	
	@DeleteMapping("tables/{id}")
	public void delTabByID(@PathVariable("id") int id)
	{
		String sql = "delete tables,par,pay,stu " +
				" from tables,par,pay,stu " +
				" where tables.tables_id = " + id +
				" and par.par_id = " + id +
				" and pay.pay_id = " + id +
				" and stu.stu_id = " + id;
		jdbc.execute(sql);
	}	
	
		@PostMapping("tables")
		public Object postTables(@RequestBody tables tab)
		{
			/*
	  {
	"tables_id": 4,
	    "tables_time": "2018.6.6",
	    "py":{
	    "pay_price": 600,
	    "pay_time": "2018.6.6"
	    },
	    "pr":{
	    "par_name": "mom6",
	    "par_phone": "156"
	    },
	    "su":{
	    "stu_name": "stu6",
	   	"stu_sex": "male",
	    "stu_age": 66
	    }
		}
			 */
			
		//tables
		String sql1= "insert into tables (tables_time) value(?)";
		Object[] args1 = {tab.getTables_time()};
		int temp = jdbc.update(sql1,args1);
		
		//pay
		String sql2 = "insert into pay (pay_price,pay_time) value(?,?)";
		Object[] args2 = {tab.getPy().getPay_price(),tab.getPy().getPay_time()};
		int temp2 = jdbc.update(sql2,args2);

		//par
		String sql3 = "insert into par (par_name,par_phone) value(?,?)";
		Object[] args3 = {tab.getPr().getPar_name(),tab.getPr().getPar_phone()};
		int temp3 = jdbc.update(sql3,args3);
		
		//stu
		String sql4 = "insert into stu (stu_name,stu_sex,stu_age) value(?,?,?)";
		Object[] args4 = {tab.getSu().getStu_name(),tab.getSu().getStu_sex(),tab.getSu().getStu_age()};
		int temp4 = jdbc.update(sql4,args4);
		
		if(temp == 1 &&  temp2 == 1 && temp3 ==1 && temp4 == 1 )
		{int tempId = tab.getTables_id() ;
		List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();
		Map<String,Object> maps=new LinkedHashMap<String,Object>();
		
		String sql = "select * from tables "
				+ "where tables_id = " + tempId;
		 List<Map<String, Object>> list1 = jdbc.queryForList(sql); 
		 for(Map<String, Object> map1:list1)
		 {
			 for(String key:map1.keySet())
			 {
			 maps.put(key, map1.get(key));
			 }
		 }
		 String sql6 = "select * from pay "
		+ "where pay_id = " + tempId;
		 List<Map<String, Object>> list2 = jdbc.queryForList(sql6); 
		 for(Map<String, Object> map2:list2)
		 {
		 maps.put("pay", map2);
		 }
		 String sql7 = "select * from par "
		+ "where par_id = " + tempId;
		 List<Map<String, Object>> list3 = jdbc.queryForList(sql7);
		 for(Map<String, Object> map3:list3)
		 {
		 maps.put("parents", map3);
		 }
		 String sql8 = "select * from stu "
		+ "where stu_id = " + tempId;
		 List<Map<String, Object>> list4 = jdbc.queryForList(sql8);
		 
		 for(Map<String, Object> map4:list4)
		 {
		 maps.put("student", map4);
		 }
		 lists.add(maps);

		return lists.get(0);
		}
			return null;
		}

	@PutMapping("tables")
	public Object putTables(@RequestBody tables tab)
	{
		
	/*
	 * 
	 * 杩欐槸POST鐨勫唴瀹�
 {
 	"tables_id": 1,
    "tables_time": "2018.666666",
    "py":{
    "pay_id": 1,
    "pay_price": 600,
    "pay_time": "2018.6.6"
    },
    "pr":{
    "par_id": 1,
    "par_name": "mom6",
    "par_phone": "156"
    },
    "su":{
    "stu_id": 1,
    "stu_name": "stu6",
   	"stu_sex": "male",
    "stu_age": 66
    }
}
	 */	
		//sql1
		String sql1 = "update tables set tables_time=? where tables_id=?";
		Object[] args1 = {tab.getTables_time(),tab.getTables_id()};
		int temp1 = jdbc.update(sql1,args1);
				
		//pay
		String sql2 = "update pay set pay_price=?,pay_time=? where pay_id=?";
		Object[] args2 = {tab.getPy().getPay_price(),tab.getPy().getPay_time(),tab.getPy().getPay_id()};
		int temp2 = jdbc.update(sql2,args2);
		
		//par
		String sql3 = "update par set par_name=?,par_phone=? where par_id=?";
		Object[] args3 = {tab.getPr().getPar_name(),tab.getPr().getPar_phone(),tab.getPr().getPar_id()};
		int temp3 = jdbc.update(sql3,args3);
				
		//stu
		String sql4 = "update stu set stu_name=?,stu_sex=?,stu_age=? where stu_id=?";
		Object[] args4 = {tab.getSu().getStu_name(),tab.getSu().getStu_sex(),tab.getSu().getStu_age(),tab.getSu().getStu_id()};
		int temp4 = jdbc.update(sql4,args4);
		
		if(temp1 == 1 && temp2 ==1 && temp3 ==1 && temp4 ==1 )
		{int tempId = tab.getTables_id() ;
		List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();
		Map<String,Object> maps=new LinkedHashMap<String,Object>();
		
		String sql = "select * from tables "
				+ "where tables_id = " + tempId;
		 List<Map<String, Object>> list1 = jdbc.queryForList(sql); 
		 for(Map<String, Object> map1:list1)
		 {
			 for(String key:map1.keySet())
			 {
			 maps.put(key, map1.get(key));
			 }
		 }
		 String sql6 = "select * from pay "
		+ "where pay_id = " + tempId;
		 List<Map<String, Object>> list2 = jdbc.queryForList(sql6); 
		 for(Map<String, Object> map2:list2)
		 {
		 maps.put("pay", map2);
		 }
		 String sql7 = "select * from par "
		+ "where par_id = " + tempId;
		 List<Map<String, Object>> list3 = jdbc.queryForList(sql7);
		 for(Map<String, Object> map3:list3)
		 {
		 maps.put("parents", map3);
		 }
		 String sql8 = "select * from stu "
		+ "where stu_id = " + tempId;
		 List<Map<String, Object>> list4 = jdbc.queryForList(sql8);
		 
		 for(Map<String, Object> map4:list4)
		 {
		 maps.put("student", map4);
		 }
		 lists.add(maps);

		return lists.get(0);
		}
		return tab;
		}

	
}


