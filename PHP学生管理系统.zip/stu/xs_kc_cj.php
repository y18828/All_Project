<h2>学生基本信息</h2>
<th>学号</th>
<th>姓名</th>
<th>性别</th>
<th>年龄</th>
<th>专业</th>
<th>班级</th>
<br/>
<?php
include_once("functions/database.php");
header('Content-Type:text/html;charset=utf-8');
//连接数据库
get_connection();

$sql ="select * from xsb";
$result = mysql_query($sql);
$num = mysql_num_rows($result);
$value=array();
while($row = mysql_fetch_array($result))
{
    $value[] = $row;
}
for($i = 0 ; $i < $num ; $i++) {
    echo "{$value[$i]['Sno']}"."     ";
    echo "{$value[$i]['Sname']}"."     ";
    echo "{$value[$i]['Ssex']}"."     ";
    echo "{$value[$i]['Sage']}"."     ";
    echo "{$value[$i]['Sclass']}"."     ";

echo"<br/>";
}

?>