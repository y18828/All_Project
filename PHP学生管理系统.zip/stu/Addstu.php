<form action="Addstu.php" method="post">
    <h2>添加学生信息</h2>
    学号：<input type="text" name="Sno"><br/>
    姓名：<input type="text" name="Sname"><br/>
    性别：<input type="radio" name="Ssex" value="男" checked/>男
    <input name="Ssex" type="radio" value="女"/>女<br/>
    年龄：<input type="text" name="Sage"><br/>
    班级：
    <select name="Sclass" size="1">
        <option value="1班" selected>1班</option>
        <option value="2班" selected>2班</option>
        <option value="3班" selected>3班</option>
        <option value="4班" selected>4班</option>
    </select><br/>
    <input type="submit" value="录入信息" name="in">
    <input type="reset" value="重置">
</form>
<?php
include_once("functions/database.php");
header('Content-Type:text/html;charset=utf-8');
get_connection();
        if (isset($_POST["in"])) {

            $Sno = $_POST['Sno'];
            $Sname = $_POST['Sname'];
            $Ssex = $_POST['Ssex'];
            $Sage = $_POST['Sage'];
            $Sclass = $_POST['Sclass'];
            get_connection();
            $sql = "select count(*) from xsb where Sno='$Sno'";
            $result = mysql_query($sql);
            $pass = mysql_fetch_row($result);
            $pa = $pass[0];
            if($pa==1)
            {
                print<<<EOF
<script>window.alert('学生信息已被添加！');window.location="http://localhost/stu/mainbody.php?url=AddStu.php";</script>
EOF;
                exit;
            }
            $sql = "insert into xsb values('$Sno','$Sname','$Ssex','$Sage','$Sclass')";
            mysql_query($sql);
            $close = mysql_close($database_connection) or die(mysql_error());
            if($close)
            {
                print<<<EOF
<script>window.alert('学生信息添加成功！');window.location="http://localhost/stu/mainbody.php?url=AddStu.php";</script>
EOF;
            }
            else
            {
                print<<<EOF
<script>window.alert('学生信息添加失败！');window.location="http://localhost/stu/mainbody.php?url=AddStu.php";</script>
EOF;
            }
        }
?>