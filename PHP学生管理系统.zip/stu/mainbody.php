<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>学生管理系统页面</title>
    <link rel="stylesheet" href="css/news.css" type="text/css">
</head>
<body>
<div id="container">
    <div id="header">
        <div id="menu">
            <ul>
                <li><a href="mainbody.php?url=xs_kc_cj.php">首页</a></li>
                <li class="menudiv"></li>
                <li><a href="mainbody.php?url=AddStu.php">信息录入</a></li>
                <li class="menudiv"></li>
                <li><a href="mainbody.php?url=StuSearch.php">信息查询</a></li>
                <li class="menudiv"></li>
                <li><a href="mainbody.php?url=AddStuScore.php">成绩录入</a></li>
                <li class="menudiv"></li>
                <li><a href="mainbody.php?url=showStukc.php">成绩查询</a></li>
                <li class="menudiv"></li>
                <li class="menudiv"></li>
            </ul>
        </div>
        <div id="banner"></div>
    </div>
    <div id="pagebody">
        <div id="sidebar">
            <div id="login">
                <br>
                <?php
                include_once("register.html");
                ?>
            </div>
        </div>
        <div id="mainbody">
            <div id="mainfunction">
                <br>
                <?php
                if(isset($_GET["url"])){
                    $url=$_GET["url"];
                }else{
                    $url="xs_kc_cj.php";
                }
                include_once($url);
                ?>

            </div>
        </div>
        <div style="clear:both;">
        </div>
    </div>
    <div id="footer">
        <a href="">联系简介</a>
        <a href="">联系方法</a>
        <a href="">相关法律</a>
        <a href="">举报违法信息</a>
        <br><br>公司版权所有
    </div>
</div>
<script>
    var sidebarHeight=document.getElementById("sidebar").clientHeight;
    var mainbodyHeight=document.getElementById("mainbody").clientHeight;
    if(sidebarHeight<500&mainbodyHeight<500){
        document.getElementById("sidebar").style.height="500px";
        document.getElementById("mainbody").style.height="500px";
    }else{
        if(sidebarHeight<mainbodyHeight){
            document.getElementById("sidebar").style.height=mainbodyHeight+"px";
        }else{
            document.getElementById("mainbody").style.height=sidebarHeight+"px";
        }
    }
</script>
</body>
</html>