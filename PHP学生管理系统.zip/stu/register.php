<?php
include_once ("functions/database.php");
//获取register.html的数据内容
header('Content-Type:text/html;charset=utf-8');
if(isset($_POST['in']))
{


$name = $_POST['name'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirmPassword'];

$str = "select password from register where name='$name'";
$result = mysql_query($str);
$pass = mysql_fetch_row($result);
$pa = $pass[0];

//判断密码是否正确
if($password != $confirmPassword)
{
    print<<<EOF
<script>window.alert('密码不正确！');window.location="http://localhost/stu/register.html";</script>
EOF;
}
else {
    print<<<EOF
<script>window.alert('登录成功！');window.location="http://localhost/stu/mainbody.php?url=xs_kc_cj.php";</script>
EOF;
}
}