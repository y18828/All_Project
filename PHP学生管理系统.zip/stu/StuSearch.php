<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="StuSearch.php" method="post">
    <h2>学生信息查询页面</h2>
    学生学号: <input type="text" name="Sno"></br>
    学生姓名: <input type="text" name="Sname"></br>
    <input type="submit" value="查询" name="in">
    <input type="reset" value="重置">
</form>
</body>
</html>
<?php
include_once("functions/database.php");
header('Content-Type:text/html;charset=utf-8');
if(isset($_POST["in"])) {

    $Sno = $_POST['Sno'];
    $Sname = $_POST['Sname'];
    get_connection();

//获取 结果集
    $result1 = mysql_query("select * from xsb where Sno='$Sno' and Sname='$Sname'");
    $pass = mysql_fetch_row(mysql_query("select count(*) from xsb where Sno='$Sno' or Sname='$Sname'"));
    $pa = $pass[0];
    $value = array();
    while ($row = mysql_fetch_array($result1)) {
        $value[] = $row;
    }
    if ($pa == 1) {
        echo "学号:  ";
        echo $value[0]['Sno'] . "<br/>";
        echo "姓名:  ";
        echo $value[0]['Sname'] . "<br/>";
        echo "性别:  ";
        echo $value[0]['Ssex'] . "<br/>";
        echo "年龄:  ";
        echo $value[0]['Sage'] . "<br/>";
        echo "班级:  ";
        echo $value[0]['Sclass'] . "<br/>";
    } else {
        print<<<EOF
<script>window.alert('无此学生信息！');window.location="http://localhost/stu/mainbody.php?url=StuSearch.php";</script>
EOF;
    }

    $close = mysql_close($database_connection) or die(mysql_error());
    if ($close)
    {
        print<<<EOF
<script>window.alert('查询学生信息成功！');function f5(){
  window.location="http://localhost/stu/mainbody.php?url=StuSearch.php";
};setTimeout("f5()",4500);</script>
EOF;
    }
}


?>