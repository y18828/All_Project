<?php
$database_connection = null;
function get_connection()
{
    $hostname = "localhost"; //本地主机
    $database = "stu";      //创建的数据库名
    $username = "root";      //本地用户名
    $password = "";          //登录密码
    global $database_connection; //定义一个全局变量
    $database_connection = @mysql_connect($hostname,$username,$password) or die(mysql_error());
    mysql_query("set names 'utf8'");   //定义字符集
    @mysql_select_db($database,$database_connection) or die(mysql_error());
}
function close_connection()
{
    global $database_connection;
    //如果连接成功
    if($database_connection)
    {
        mysql_close($database_connection) or die(mysql_error());
    }
}
?>