<?php
header('Content-Type:text/html;charset=utf-8');
echo"快乐"."  ";
echo"123";
?>