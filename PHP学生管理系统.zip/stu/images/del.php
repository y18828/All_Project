<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");
switch($_GET['action']) {
    case "del":
        $link = mysql_connect("localhost", "root", "") or die(mysql_error());
        if ($link) {
            $select = mysql_select_db("pxscj", $link) or die(mysql_error());
            if ($select) {
                $key1 = $_GET['key1'];
                mysql_query("set names 'utf8'");
                $sql = "delete from xsb where Sno={$key1}";
                mysql_query($sql, $link);
                $close = mysql_close($link) or die(mysql_error());
                if ($close) {
                    print<<<EOF
<script>window.alert('删除学生成功！');window.location="http://localhost/MFC ODBC/main.php";</script>
EOF;

                }
            }
        }
        break;

    case "del2":
        $link = mysql_connect("localhost", "root", "") or die(mysql_error());
        if ($link)
        {
            $select = mysql_select_db("pxscj", $link) or die(mysql_error());
            if ($select)
            {
                $key2 = $_GET['key2'];
                mysql_query("set names 'utf8'");
                $sql = "delete from kcb where Cno={$key2}";
                mysql_query($sql, $link);
                $close = mysql_close($link) or die(mysql_error());
                if ($close)
                {
                    print<<<EOF
<script>window.alert('删除课程成功！');window.location="http://localhost/MFC ODBC/main.php";</script>
EOF;
                }
            }
        }
        break;
}