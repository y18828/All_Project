<form action="showStukc.php" method="post">
    <h2>成绩查询</h2>
    学生学号：<input type="text" name="Sno"><br/>
    课程编号：<input type="text" name="Cno"><br/>
    <input type="submit" value="查询" name="in">
    <input type="reset" value="重置">
</form>
<?php
include_once("functions/database.php");
header('Content-Type:text/html;charset=utf-8');
get_connection();
//查询该学生学号
if(isset($_POST['in']))
{
    get_connection();
    $Sno = $_POST['Sno'];
    $Cno = $_POST['Cno'];
    $sql = "select * from cjb where Sno='$Sno' and Cno='$Cno'";
    $str = "select count(*) from cjb  where Sno='$Sno}' and Sname='$search'";
    $result1 = mysql_query($str);
    $result = mysql_query($sql);
    $num = mysql_num_rows($result);
    $value = array();
    while ($row = mysql_fetch_array($result))
    {
        $value[] = $row;
    }
    if($num)
    {
        for($i=0;$i<$num;$i++)
        {

            echo "{$value[$i]['Sno']}"."  ";
            echo "{$value[$i]['Cno']}"."  ";
            echo "{$value[$i]['Grade']}"."  ";
            echo "</br>";
        }
    }
    else
    {
        print<<<EOF
<script>window.alert('无法查询此信息！');window.location="http://localhost/stu/mainbody.php?url=showStukc.php";</script>
EOF;

    }
    $close=mysql_close($database_connection) or die(mysql_error());
    if ($close)
    {
        print<<<EOF
<script>window.alert('查询学生成绩成功！');function f5(){
  window.location="http://localhost/stu/mainbody.php?url=showStukc.php";
};setTimeout("f5()",4500);</script>
EOF;
    }
}

?>