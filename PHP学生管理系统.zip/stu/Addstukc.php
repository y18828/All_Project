<?php
include_once("functions/database.php");
header('Content-Type:text/html;charset=utf-8');
//课程添加
get_connection();
mysql_query("insert into kcb value('1','语文',4,'8')");
mysql_query("insert into kcb value('2','数学',4,'10')");
mysql_query("insert into kcb value('3','英语','4','12')");
echo"添加课程信息成功";
close_connection();

?>