<form action="AddStuScore.php" method="post">
    <h2>成绩录入</h2>
    学生学号：<input type="text" name="Sno"><br/>
    课程编号：<input type="text" name="Cno"><br/>
    课程成绩：<input type="text" name="Grade"><br/>
    <input type="submit" value="录入成绩" name="in">
    <input type="reset" value="重置">
</form>
<?php
include_once("functions/database.php");
header('Content-Type:text/html;charset=utf-8');
get_connection();
if (isset($_POST["in"]))
{
    $Sno = $_POST['Sno'];
    $Cno = $_POST['Cno'];
    $Grade = $_POST['Grade'];
    $sql = "select count(*) from cjb where Sno='{$Sno}' and Cno='{$Cno}'";
    $result = mysql_query($sql);
    $pass = mysql_fetch_row($result);
    $pa = $pass[0];
    if ($pa == 1)
    {
        print<<<EOF
<script>window.alert('学生该成绩已被添加!');window.location="http://localhost/stu/mainbody.php?url=AddStuScore.php";</script>
EOF;
        exit;
    }
    else
    {
        $sql = "insert into cjb values('{$Sno}','{$Cno}','{$Grade}')";
        mysql_query($sql);
        $close = mysql_close($database_connection) or die(mysql_error());
        if ($close)
        {
            print<<<EOF
<script>window.alert('成绩添加成功！');window.location="http://localhost/stu/mainbody.php?url=AddStuScore.php";</script>
EOF;
        }
        else
        {
            print<<<EOF
<script>window.alert('成绩添加失败！');window.location="http://localhost/stu/mainbody.php?url=AddStuScore.php";</script>
EOF;
        }
    }
}
?>